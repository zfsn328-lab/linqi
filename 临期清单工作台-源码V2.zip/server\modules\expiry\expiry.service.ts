import { Inject, Injectable, NotFoundException } from '@nestjs/common';
import { DRIZZLE_DATABASE, type PostgresJsDatabase } from '@lark-apaas/fullstack-nestjs-core';
import { eq, and, desc, asc, inArray } from 'drizzle-orm';
import { expiryItem, expirySetting } from '../../database/schema';
import type { ExpiryItem, CreateExpiryItemDto, UpdateExpiryItemDto } from '@shared/api.interface';

@Injectable()
export class ExpiryService {
  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
  ) {}

  async findAll(): Promise<ExpiryItem[]> {
    const rows = await this.db
      .select()
      .from(expiryItem)
      .orderBy(asc(expiryItem.expiry), asc(expiryItem.createdAt));
    return rows.map(row => this.toDto(row));
  }

  async findActive(): Promise<ExpiryItem[]> {
    const rows = await this.db
      .select()
      .from(expiryItem)
      .where(eq(expiryItem.status, 'active'))
      .orderBy(asc(expiryItem.expiry), asc(expiryItem.createdAt));
    return rows.map(row => this.toDto(row));
  }

  async create(dto: CreateExpiryItemDto): Promise<ExpiryItem> {
    const today = new Date().toISOString().split('T')[0];
    const rows = await this.db
      .insert(expiryItem)
      .values({
        name: dto.name,
        emoji: dto.emoji || '',
        expiry: dto.expiry,
        status: 'active',
        createdAt: today,
      })
      .returning();
    return this.toDto(rows[0]);
  }

  async updateStatus(id: string, dto: UpdateExpiryItemDto): Promise<ExpiryItem> {
    const rows = await this.db
      .update(expiryItem)
      .set({
        status: dto.status,
        processedAt: dto.processedAt || null,
      })
      .where(eq(expiryItem.id, id))
      .returning();
    if (rows.length === 0) {
      throw new NotFoundException('记录不存在');
    }
    return this.toDto(rows[0]);
  }

  async remove(id: string): Promise<void> {
    const rows = await this.db
      .delete(expiryItem)
      .where(eq(expiryItem.id, id))
      .returning({ id: expiryItem.id });
    if (rows.length === 0) {
      throw new NotFoundException('记录不存在');
    }
  }

  async clearAll(): Promise<void> {
    await this.db.delete(expiryItem);
  }

  async batchImport(items: CreateExpiryItemDto[]): Promise<ExpiryItem[]> {
    if (items.length === 0) return [];
    const today = new Date().toISOString().split('T')[0];
    const values = items.map(it => ({
      name: it.name,
      emoji: it.emoji || '',
      expiry: it.expiry,
      status: 'active' as const,
      createdAt: today,
    }));
    const rows = await this.db
      .insert(expiryItem)
      .values(values)
      .returning();
    return rows.map(row => this.toDto(row));
  }

  async getSetting(key: string): Promise<string | null> {
    const rows = await this.db
      .select()
      .from(expirySetting)
      .where(eq(expirySetting.settingKey, key));
    return rows.length > 0 ? rows[0].settingValue : null;
  }

  async setSetting(key: string, value: string): Promise<void> {
    const existing = await this.db
      .select()
      .from(expirySetting)
      .where(eq(expirySetting.settingKey, key));
    if (existing.length > 0) {
      await this.db
        .update(expirySetting)
        .set({ settingValue: value })
        .where(eq(expirySetting.settingKey, key));
    } else {
      await this.db
        .insert(expirySetting)
        .values({ settingKey: key, settingValue: value });
    }
  }

  private toDto(row: typeof expiryItem.$inferSelect): ExpiryItem {
    return {
      id: row.id,
      name: row.name,
      emoji: row.emoji,
      expiry: row.expiry,
      status: row.status as 'active' | 'eaten' | 'thrown',
      processedAt: row.processedAt || '',
      createdAt: row.createdAt,
    };
  }
}
