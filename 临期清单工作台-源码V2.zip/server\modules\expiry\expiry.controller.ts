import { Controller, Get, Post, Put, Delete, Body, Param, BadRequestException } from '@nestjs/common';
import { ExpiryService } from './expiry.service';
import type {
  ExpiryItem,
  CreateExpiryItemDto,
  UpdateExpiryItemDto,
  ExpiryListResponse,
  BatchImportDto,
} from '@shared/api.interface';

@Controller('api/expiry')
export class ExpiryController {
  constructor(private readonly expiryService: ExpiryService) {}

  @Get('items')
  async getItems(): Promise<ExpiryListResponse> {
    const items = await this.expiryService.findAll();
    return { items };
  }

  @Post('items')
  async createItem(@Body() dto: CreateExpiryItemDto): Promise<ExpiryItem> {
    if (!dto.name || !dto.name.trim()) {
      throw new BadRequestException('物品名称不能为空');
    }
    if (!dto.expiry || !/^\d{4}-\d{2}-\d{2}$/.test(dto.expiry)) {
      throw new BadRequestException('到期日期格式不正确');
    }
    return this.expiryService.create({
      name: dto.name.trim(),
      emoji: dto.emoji || '',
      expiry: dto.expiry,
    });
  }

  @Put('items/:id/status')
  async updateStatus(
    @Param('id') id: string,
    @Body() dto: UpdateExpiryItemDto,
  ): Promise<ExpiryItem> {
    if (!dto.status || !['active', 'eaten', 'thrown'].includes(dto.status)) {
      throw new BadRequestException('状态值不正确');
    }
    return this.expiryService.updateStatus(id, dto);
  }

  @Delete('items/:id')
  async deleteItem(@Param('id') id: string): Promise<{ success: boolean }> {
    await this.expiryService.remove(id);
    return { success: true };
  }

  @Delete('items')
  async clearAll(): Promise<{ success: boolean }> {
    await this.expiryService.clearAll();
    return { success: true };
  }

  @Post('items/batch-import')
  async batchImport(@Body() dto: BatchImportDto): Promise<ExpiryItem[]> {
    if (!Array.isArray(dto.items)) {
      throw new BadRequestException('items 必须是数组');
    }
    const validItems = dto.items.filter(it =>
      it.name && it.name.trim() && it.expiry && /^\d{4}-\d{2}-\d{2}$/.test(it.expiry),
    );
    return this.expiryService.batchImport(validItems);
  }

  @Get('settings/:key')
  async getSetting(@Param('key') key: string): Promise<{ key: string; value: string }> {
    const value = await this.expiryService.getSetting(key);
    return { key, value: value || '' };
  }

  @Put('settings/:key')
  async setSetting(
    @Param('key') key: string,
    @Body() body: { value: string },
  ): Promise<{ success: boolean }> {
    await this.expiryService.setSetting(key, String(body.value || ''));
    return { success: true };
  }
}
