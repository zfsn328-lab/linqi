export interface ExpiryItem {
  id: string;
  name: string;
  emoji: string;
  expiry: string;
  status: 'active' | 'eaten' | 'thrown';
  processedAt: string;
  createdAt: string;
}

export interface CreateExpiryItemDto {
  name: string;
  emoji?: string;
  expiry: string;
}

export interface UpdateExpiryItemDto {
  status: 'active' | 'eaten' | 'thrown';
  processedAt?: string;
}

export interface ExpirySetting {
  key: string;
  value: string;
}

export interface BatchImportDto {
  items: Omit<ExpiryItem, 'id'>[];
}

export interface ExpiryListResponse {
  items: ExpiryItem[];
}
