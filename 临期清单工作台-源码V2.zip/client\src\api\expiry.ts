import { axiosForBackend } from '@lark-apaas/client-toolkit/utils/getAxiosForBackend';
import type {
  ExpiryItem,
  CreateExpiryItemDto,
  UpdateExpiryItemDto,
  ExpiryListResponse,
  BatchImportDto,
} from '@shared/api.interface';

export const MARKER_PREFIX = '__MARKER__:';
export const MARKER_EXPIRY = '2099-12-31';

export type MarkerOp = 'DEL' | 'EAT' | 'THROW' | 'RST';

export interface ParsedMarker {
  op: MarkerOp;
  targetId: string;
  timestamp: number;
  raw: string;
}

export function isMarkerItem(item: ExpiryItem): boolean {
  return item.name.startsWith(MARKER_PREFIX);
}

export function parseMarker(item: ExpiryItem): ParsedMarker | null {
  if (!item.name.startsWith(MARKER_PREFIX)) return null;
  const parts = item.name.slice(MARKER_PREFIX.length).split(':');
  if (parts.length < 3) return null;
  const op = parts[0] as MarkerOp;
  const ts = parseInt(parts[parts.length - 1], 10);
  const targetId = parts.slice(1, -1).join(':');
  if (['DEL', 'EAT', 'THROW', 'RST'].indexOf(op) < 0 || isNaN(ts) || !targetId) return null;
  return { op, targetId, timestamp: ts, raw: item.name };
}

export function buildMarkerName(op: MarkerOp, targetId: string, timestamp: number): string {
  return `${MARKER_PREFIX}${op}:${targetId}:${timestamp}`;
}

export async function writeMarker(op: MarkerOp, targetId: string): Promise<ExpiryItem> {
  return createItem({
    name: buildMarkerName(op, targetId, Date.now()),
    emoji: '',
    expiry: MARKER_EXPIRY,
  });
}

export interface ResolvedItem extends ExpiryItem {
  displayStatus: 'active' | 'eaten' | 'thrown' | 'deleted';
  markerProcessedAt: string;
}

export function resolveItemsWithMarkers(items: ExpiryItem[]): ResolvedItem[] {
  const markers: ParsedMarker[] = [];
  const realItems: ExpiryItem[] = [];

  for (const it of items) {
    const m = parseMarker(it);
    if (m) {
      markers.push(m);
    } else {
      realItems.push(it);
    }
  }

  const latestByTarget = new Map<string, ParsedMarker>();
  for (const m of markers) {
    const prev = latestByTarget.get(m.targetId);
    if (!prev || m.timestamp > prev.timestamp) {
      latestByTarget.set(m.targetId, m);
    }
  }

  return realItems.map(item => {
    const marker = latestByTarget.get(item.id);
    if (!marker) {
      return {
        ...item,
        displayStatus: item.status as 'active' | 'eaten' | 'thrown',
        markerProcessedAt: item.processedAt || '',
      };
    }

    let displayStatus: 'active' | 'eaten' | 'thrown' | 'deleted' = 'active';
    switch (marker.op) {
      case 'DEL': displayStatus = 'deleted'; break;
      case 'EAT': displayStatus = 'eaten'; break;
      case 'THROW': displayStatus = 'thrown'; break;
      case 'RST': displayStatus = 'active'; break;
    }

    const markerDate = new Date(marker.timestamp);
    const y = markerDate.getFullYear();
    const mo = String(markerDate.getMonth() + 1).padStart(2, '0');
    const d = String(markerDate.getDate()).padStart(2, '0');
    const markerDateStr = `${y}-${mo}-${d}`;

    return {
      ...item,
      displayStatus,
      markerProcessedAt: markerDateStr,
    };
  });
}

export async function getItems(): Promise<ExpiryItem[]> {
  const res = await axiosForBackend.get<ExpiryListResponse>('/api/expiry/items');
  return res.data.items;
}

export async function createItem(dto: CreateExpiryItemDto): Promise<ExpiryItem> {
  const res = await axiosForBackend.post<ExpiryItem>('/api/expiry/items', dto);
  return res.data;
}

export async function updateItemStatus(id: string, dto: UpdateExpiryItemDto): Promise<ExpiryItem> {
  const res = await axiosForBackend.put<ExpiryItem>(`/api/expiry/items/${id}/status`, dto);
  return res.data;
}

export async function deleteItem(id: string): Promise<void> {
  await axiosForBackend.delete(`/api/expiry/items/${id}`);
}

export async function clearAllItems(): Promise<void> {
  await axiosForBackend.delete('/api/expiry/items');
}

export async function batchImport(dto: BatchImportDto): Promise<ExpiryItem[]> {
  const res = await axiosForBackend.post<ExpiryItem[]>('/api/expiry/items/batch-import', dto);
  return res.data;
}

export async function getSetting(key: string): Promise<string> {
  const res = await axiosForBackend.get<{ key: string; value: string }>(`/api/expiry/settings/${key}`);
  return res.data.value;
}

export async function setSetting(key: string, value: string): Promise<void> {
  await axiosForBackend.put(`/api/expiry/settings/${key}`, { value });
}
