import { useState, useEffect, useRef, useCallback } from 'react';
import { logger } from '@lark-apaas/client-toolkit/logger';
import {
  getItems,
  createItem,
  updateItemStatus,
  deleteItem,
  clearAllItems,
  batchImport,
  getSetting,
  setSetting,
  writeMarker,
  resolveItemsWithMarkers,
  type ResolvedItem,
} from '../../api/expiry';
import type { ExpiryItem, CreateExpiryItemDto } from '@shared/api.interface';
import './expiry.css';

const TUT_IOS = [
  '用苹果自带浏览器Safari打开「临期清单」这个网址链接',
  '点击「导出日历」，浏览器会下载一个 .ics 文件「下载」',
  '点击下载好的文件，系统会自动导入物品和日期到「日历」中并弹出「日历」预览，然后点击右上角添加',
  '到期日的前一天上午9点，手机会收到日历提醒',
];
const TUT_ANDROID = [
  '点击「导出日历」，浏览器会下载一个 .ics 文件',
  '在「文件管理 → 下载」中找到该文件',
  '选择「用日历打开」',
  '点击「导入」或「保存」',
  '完成',
];
const EMOJI_PICK = ['🥛', '🥚', '🍞', '🍓', '🍌', '🍎', '💊', '🍗'];
const EMOJI_MAP: [string, string][] = [
  ['奶', '🥛'], ['蛋', '🥚'], ['面包', '🍞'], ['草莓', '🍓'], ['香蕉', '🍌'], ['苹果', '🍎'],
  ['橙', '🍊'], ['梨', '🍐'], ['葡萄', '🍇'], ['桃', '🍑'], ['西瓜', '🍉'], ['芒果', '🥭'],
  ['蓝莓', '🫐'], ['菠萝', '🍍'], ['番茄', '🍅'], ['黄瓜', '🥒'], ['菜花', '🥦'], ['西兰花', '🥦'],
  ['蘑菇', '🍄'], ['菜', '🥬'], ['土豆', '🥔'], ['玉米', '🌽'], ['肉', '🥩'], ['牛', '🥩'],
  ['羊', '🥩'], ['猪', '🥩'], ['培根', '🥓'], ['香肠', '🌭'], ['火腿', '🍖'], ['鸡', '🍗'],
  ['鸭', '🦆'], ['鱼', '🐟'], ['虾', '🦐'], ['蟹', '🦀'], ['豆腐', '🫘'], ['药', '💊'],
  ['布洛芬', '💊'], ['维生素', '💊'], ['蜂蜜', '🍯'], ['奶酪', '🧀'], ['芝士', '🧀'],
  ['黄油', '🧈'], ['罐头', '🥫'], ['果汁', '🧃'], ['咖啡', '☕'], ['茶', '🍵'],
  ['饮料', '🥤'], ['可乐', '🥤'], ['啤酒', '🍺'], ['米饭', '🍚'], ['饺子', '🥟'],
  ['包子', '🥟'], ['面条', '🍜'], ['粥', '🥣'], ['汤', '🍲'], ['巧克力', '🍫'],
  ['饼干', '🍪'], ['蛋糕', '🍰'], ['冰淇淋', '🍨'], ['坚果', '🥜'], ['花生', '🥜'],
  ['面', '🍜'],
];
const PAGE_SIZE = 10;

const SAMPLE_SPECS = [
  { emoji: '🍓', name: '草莓', days: -1 },
  { emoji: '🍗', name: '卤鸡腿', days: -2 },
  { emoji: '🫘', name: '盒装豆腐', days: -3 },
  { emoji: '🍞', name: '切片面包', days: 3 },
  { emoji: '🧀', name: '芝士片', days: 3 },
  { emoji: '🍌', name: '香蕉', days: 2 },
  { emoji: '🍅', name: '番茄', days: 1 },
  { emoji: '🥛', name: '牛奶', days: 27 },
  { emoji: '🥛', name: '酸奶', days: 5 },
  { emoji: '🥚', name: '鸡蛋', days: 12 },
  { emoji: '🍎', name: '苹果', days: 14 },
  { emoji: '🍊', name: '橙子', days: 10 },
  { emoji: '🍇', name: '葡萄', days: 6 },
  { emoji: '🥦', name: '西兰花', days: 8 },
  { emoji: '🥒', name: '黄瓜', days: 5 },
  { emoji: '🥔', name: '土豆', days: 20 },
  { emoji: '🍄', name: '蘑菇', days: 7 },
  { emoji: '🐟', name: '三文鱼', days: 4 },
  { emoji: '🍫', name: '巧克力', days: 60 },
  { emoji: '💊', name: '布洛芬', days: 260 },
];

function todayStr(): string {
  const d = new Date();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const dd = String(d.getDate()).padStart(2, '0');
  return `${d.getFullYear()}-${m}-${dd}`;
}
function parseDate(s: string): Date {
  const p = s.split('-');
  return new Date(parseInt(p[0], 10), parseInt(p[1], 10) - 1, parseInt(p[2], 10));
}
function formatDate(d: Date): string {
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const dd = String(d.getDate()).padStart(2, '0');
  return `${d.getFullYear()}-${m}-${dd}`;
}
function addDays(d: Date, n: number): Date {
  const x = new Date(d.getFullYear(), d.getMonth(), d.getDate());
  x.setDate(x.getDate() + n);
  return x;
}
function daysUntil(expiry: string): number {
  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  return Math.round((parseDate(expiry).getTime() - today.getTime()) / 86400000);
}
function fmtDate(s: string): string {
  const d = parseDate(s);
  return `${d.getFullYear()}/${String(d.getMonth() + 1).padStart(2, '0')}/${String(d.getDate()).padStart(2, '0')}`;
}
function compactDate(d: Date): string {
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const dd = String(d.getDate()).padStart(2, '0');
  return `${d.getFullYear()}${m}${dd}`;
}
function icsStamp(): string {
  return new Date().toISOString().replace(/[-:]/g, '').split('.')[0] + 'Z';
}
function statusOf(days: number): 'expired' | 'imminent' | 'safe' {
  if (days <= 0) return 'expired';
  if (days <= 3) return 'imminent';
  return 'safe';
}
function statusText(days: number): string {
  if (days < 0) return `已过期 ${-days} 天`;
  if (days === 0) return '今天到期';
  return `还剩 ${days} 天`;
}
function suggestion(days: number): string {
  if (days <= 0) return '建议：检查后丢弃';
  if (days <= 3) return '建议：今天优先吃掉';
  return '建议：放到冰箱显眼位置';
}
// ics 提醒在「到期前 remindDays 天的早上 09:00」触发，因此提醒触发当天的真实剩余天数
// 恒等于 remindDays（不是导出当天的 daysUntil——导出快照会随时间漂移，旧版写死
// 「还剩 N 天」导致提醒日文案与实际不符）。这里用触发日相对天数 + 到期日双写，保证任何场景不歧义。
function alertRemainText(remain: number): string {
  if (remain <= 0) return '今日到期';
  if (remain === 1) return '明日到期';
  return `${remain} 天后到期`;
}
function fmtExpiryCn(iso: string): string {
  const parts = iso.split('-');
  return `${parseInt(parts[1], 10)}月${parseInt(parts[2], 10)}日`;
}
function guessEmoji(name: string): string {
  for (let i = 0; i < EMOJI_MAP.length; i++) {
    if (name.indexOf(EMOJI_MAP[i][0]) > -1) return EMOJI_MAP[i][1];
  }
  return '';
}
function buildSamples(): CreateExpiryItemDto[] {
  const now = new Date();
  return SAMPLE_SPECS.map(s => ({
    name: s.name,
    emoji: s.emoji,
    expiry: formatDate(addDays(now, s.days)),
  }));
}

const GenericIcon = () => (
  <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="#8D9792" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">
    <path d="M3.5 7.5 L12 3 l8.5 4.5 v9 L12 21 l-8.5-4.5 z" />
    <path d="M3.5 7.5 L12 12 l8.5-4.5" />
    <path d="M12 12v9" />
  </svg>
);
const GenericIconSm = () => (
  <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="#8D9792" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <path d="M3.5 7.5 L12 3 l8.5 4.5 v9 L12 21 l-8.5-4.5 z" />
    <path d="M3.5 7.5 L12 12 l8.5-4.5" />
    <path d="M12 12v9" />
  </svg>
);

export default function ExpiryListPage() {
  const [items, setItems] = useState<ExpiryItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [samplesVisible, setSamplesVisible] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedEmoji, setSelectedEmoji] = useState('');
  const [processedOpen, setProcessedOpen] = useState(true);
  const [remindDays, setRemindDays] = useState(1);

  const [nameInput, setNameInput] = useState('');
  const [dateInput, setDateInput] = useState('');
  const [inputError, setInputError] = useState(false);
  const [inputShake, setInputShake] = useState(false);

  const [showCalendar, setShowCalendar] = useState(false);
  const [calView, setCalView] = useState({ y: 0, m: 0 });
  const [showConfirm, setShowConfirm] = useState(false);
  const [confirmData, setConfirmData] = useState<{
    title: string; msg: string; confirmText: string; danger: boolean; onConfirm: () => void;
  } | null>(null);
  const [showTutorial, setShowTutorial] = useState(false);
  const [tutPlatform, setTutPlatform] = useState<'ios' | 'android'>('ios');

  const [toasts, setToasts] = useState<{ id: number; msg: string; type: string }[]>([]);
  const toastIdRef = useRef(0);

  const nameInputRef = useRef<HTMLInputElement>(null);
  const dateTriggerRef = useRef<HTMLButtonElement>(null);
  const datePickerRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const dtScrollRef = useRef<HTMLSpanElement>(null);
  const dtTextRef = useRef<HTMLSpanElement>(null);

  const showToast = useCallback((msg: string, type = '') => {
    const id = ++toastIdRef.current;
    setToasts(prev => [...prev, { id, msg, type }]);
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, 2800);
  }, []);

  const loadItems = useCallback(async () => {
    try {
      setLoading(true);
      const data = await getItems();
      setItems(data);
      const realCount = data.filter(it => !it.name.startsWith('__MARKER__:')).length;
      if (realCount === 0) {
        setSamplesVisible(true);
        const samples = buildSamples();
        setItems(samples.map((s, i) => ({
          id: `sample-${s.name}-${i}`,
          name: s.name,
          emoji: s.emoji || '',
          expiry: s.expiry,
          status: 'active' as const,
          processedAt: '',
          createdAt: todayStr(),
        })));
      }
    } catch (err) {
      logger.error('加载物品失败', err);
      showToast('加载失败，请刷新重试', 'error');
    } finally {
      setLoading(false);
    }
  }, [showToast]);

  const loadRemindDays = useCallback(async () => {
    try {
      const val = await getSetting('remind_days');
      if (val) {
        const n = parseInt(val, 10);
        if (!isNaN(n) && n >= 0) setRemindDays(n);
      }
    } catch (err) {
      logger.error('加载提醒天数失败', err);
    }
  }, []);

  useEffect(() => {
    loadItems();
    loadRemindDays();
  }, [loadItems, loadRemindDays]);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (!showCalendar) return;
      const tr = dateTriggerRef.current;
      const pk = datePickerRef.current;
      if (tr && pk && !tr.contains(e.target as Node) && !pk.contains(e.target as Node)) {
        setShowCalendar(false);
      }
    };
    document.addEventListener('click', handleClickOutside);
    return () => document.removeEventListener('click', handleClickOutside);
  }, [showCalendar]);

  useEffect(() => {
    const handleEsc = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        if (showTutorial) setShowTutorial(false);
        else if (showConfirm) { setShowConfirm(false); setConfirmData(null); }
        else if (showCalendar) setShowCalendar(false);
      }
    };
    document.addEventListener('keydown', handleEsc);
    return () => document.removeEventListener('keydown', handleEsc);
  }, [showTutorial, showConfirm, showCalendar]);

  useEffect(() => {
    if (!dateInput || !dtScrollRef.current || !dtTextRef.current) return;
    const outer = dtTextRef.current;
    const wrap = dtScrollRef.current;
    const tx = wrap.scrollWidth - outer.clientWidth;
    if (tx > 0) {
      outer.classList.add('scroll');
      outer.style.setProperty('--tx', `${-tx}px`);
      outer.style.setProperty('--dur', `${Math.max(5, Math.min(10, Math.round(tx / 13)))}s`);
    } else {
      outer.classList.remove('scroll');
    }
  }, [dateInput]);

  const resolvedItems = resolveItemsWithMarkers(items);

  const realItems = resolvedItems.filter(it =>
    it.displayStatus !== 'deleted' && !String(it.id).startsWith('sample-')
  );

  const visibleItems = samplesVisible ? resolvedItems.filter(it =>
    it.displayStatus !== 'deleted'
  ) : realItems;

  const activeItems = visibleItems.filter(it => it.displayStatus === 'active');
  const expiredCount = activeItems.filter(it => daysUntil(it.expiry) <= 0).length;
  const imminentCount = activeItems.filter(it => {
    const d = daysUntil(it.expiry);
    return d > 0 && d <= 3;
  }).length;
  const safeCount = activeItems.filter(it => daysUntil(it.expiry) > 3).length;

  const searchedActive = activeItems
    .filter(it => {
      const q = searchQuery.trim().toLowerCase();
      if (!q) return true;
      return it.name.toLowerCase().indexOf(q) > -1 ||
        (it.emoji && it.emoji.indexOf(q) > -1);
    })
    .sort((a, b) => {
      if (a.expiry !== b.expiry) return a.expiry < b.expiry ? -1 : 1;
      return a.createdAt < b.createdAt ? -1 : 1;
    });

  const totalPages = Math.max(1, Math.ceil(searchedActive.length / PAGE_SIZE));
  const safePage = Math.min(currentPage, totalPages);
  const pageList = searchedActive.slice((safePage - 1) * PAGE_SIZE, safePage * PAGE_SIZE);

  const processedItems = visibleItems
    .filter(it => it.displayStatus === 'eaten' || it.displayStatus === 'thrown')
    .sort((a, b) => (a.markerProcessedAt || a.createdAt) < (b.markerProcessedAt || b.createdAt) ? 1 : -1);

  const handleAddItem = async () => {
    const name = nameInput.trim();
    if (!name) {
      setInputError(true);
      setInputShake(false);
      requestAnimationFrame(() => setInputShake(true));
      nameInputRef.current?.focus();
      return;
    }
    let expiry = dateInput;
    let usedDefault = false;
    if (!expiry) {
      expiry = formatDate(addDays(new Date(), 7));
      usedDefault = true;
    }
    const emoji = selectedEmoji || guessEmoji(name);

    if (samplesVisible) {
      await clearAllItems();
      setSamplesVisible(false);
    }

    try {
      const newItem = await createItem({ name, emoji, expiry });
      setItems(prev => {
        const real = prev.filter(it => !String(it.id).startsWith('sample-'));
        return [...real, newItem];
      });
      setCurrentPage(1);
      setNameInput('');
      nameInputRef.current?.focus();
      showToast(usedDefault ? `已记下 ${name}（未选日期，默认记为 7 天后）` : `已记下 ${name}`);
    } catch (err) {
      logger.error('添加物品失败', err);
      showToast('添加失败，请重试', 'error');
    }
  };

  const handleQuickDate = (days: number) => {
    const d = addDays(new Date(), days);
    setDateInput(formatDate(d));
    setShowCalendar(false);
    nameInputRef.current?.focus();
  };

  const handlePickEmoji = (em: string) => {
    setSelectedEmoji(prev => (prev === em ? '' : em));
    nameInputRef.current?.focus();
  };

  const handleClearEmoji = () => {
    setSelectedEmoji('');
    nameInputRef.current?.focus();
  };

  const handleMarkStatus = async (id: string, st: 'eaten' | 'thrown') => {
    const resolved = resolvedItems.find(it => it.id === id);
    if (!resolved) return;
    const itemName = resolved.name;
    if (String(id).startsWith('sample-')) {
      setItems(prev => prev.map(it =>
        it.id === id ? { ...it, status: st, processedAt: todayStr() } : it,
      ));
      showToast(st === 'eaten' ? `已标记「${itemName}」为已吃掉` : `已标记「${itemName}」为已扔掉`);
      return;
    }
    try {
      await writeMarker(st === 'eaten' ? 'EAT' : 'THROW', id);
    } catch (err) {
      logger.error('写入标记失败', err);
      showToast('操作失败，请重试', 'error');
      return;
    }
    try {
      const updated = await updateItemStatus(id, { status: st, processedAt: todayStr() });
      setItems(prev => prev.map(it => (it.id === id ? updated : it)));
    } catch (err) {
      logger.error('更新状态失败（未登录，已用标记条目替代）', err);
      const fresh = await getItems();
      setItems(fresh);
    }
    showToast(st === 'eaten' ? `已标记「${itemName}」为已吃掉` : `已标记「${itemName}」为已扔掉`);
  };

  const handleRestoreItem = async (id: string) => {
    const resolved = resolvedItems.find(it => it.id === id);
    if (!resolved) return;
    const itemName = resolved.name;
    if (String(id).startsWith('sample-')) {
      setItems(prev => prev.map(it =>
        it.id === id ? { ...it, status: 'active', processedAt: '' } : it,
      ));
      showToast(`已恢复「${itemName}」`);
      return;
    }
    try {
      await writeMarker('RST', id);
    } catch (err) {
      logger.error('写入恢复标记失败', err);
      showToast('操作失败，请重试', 'error');
      return;
    }
    try {
      const updated = await updateItemStatus(id, { status: 'active', processedAt: '' });
      setItems(prev => prev.map(it => (it.id === id ? updated : it)));
    } catch (err) {
      logger.error('恢复失败（未登录，已用标记条目替代）', err);
      const fresh = await getItems();
      setItems(fresh);
    }
    showToast(`已恢复「${itemName}」`);
  };

  const handleRemoveItem = (id: string) => {
    const resolved = resolvedItems.find(it => it.id === id);
    if (!resolved) return;
    const itemName = resolved.name;
    setConfirmData({
      title: '删除这条记录？',
      msg: `「${itemName}」删除后无法找回，确定删除吗？`,
      confirmText: '删除',
      danger: true,
      onConfirm: async () => {
        if (String(id).startsWith('sample-')) {
          setItems(prev => prev.filter(it => it.id !== id));
          showToast('已删除');
          return;
        }
        try {
          await writeMarker('DEL', id);
        } catch (err) {
          logger.error('写入删除标记失败', err);
          showToast('删除失败，请重试', 'error');
          return;
        }
        try {
          await deleteItem(id);
          setItems(prev => prev.filter(it => it.id !== id));
        } catch (err) {
          logger.error('删除失败（未登录，已用标记条目替代）', err);
          const fresh = await getItems();
          setItems(fresh);
        }
        showToast('已删除');
      },
    });
    setShowConfirm(true);
  };

  const handleClearSamples = () => {
    setSamplesVisible(false);
    setItems([]);
    setCurrentPage(1);
    showToast('已清空示例，开始记录吧');
  };

  const handleAdoptSamples = async () => {
    try {
      const samples = buildSamples();
      const imported = await batchImport({ items: samples as any });
      setItems(imported);
      setSamplesVisible(false);
      setCurrentPage(1);
      showToast(`已用 ${SAMPLE_SPECS.length} 条示例开始记录`);
    } catch (err) {
      logger.error('导入示例失败', err);
      showToast('导入失败，请重试', 'error');
    }
  };

  const handleRemindChange = async (e: React.ChangeEvent<HTMLSelectElement>) => {
    const val = parseInt(e.target.value, 10) || 1;
    setRemindDays(val);
    try {
      await setSetting('remind_days', String(val));
      showToast(`到期提醒已改为提前 ${val} 天`);
    } catch (err) {
      logger.error('保存提醒天数失败', err);
    }
  };

  const exportIcs = () => {
    const active = activeItems.slice().sort((a, b) => a.expiry < b.expiry ? -1 : 1);
    if (active.length === 0) {
      showToast('还没有可导出的条目，先记一件吧', 'error');
      return;
    }
    const lines = [
      'BEGIN:VCALENDAR',
      'VERSION:2.0',
      'PRODID:-//Linqi Qingdan//CN',
      'CALSCALE:GREGORIAN',
      'METHOD:PUBLISH',
    ];
    const uids: Record<string, number> = {};
    active.forEach(it => {
      const alertRemain = alertRemainText(remindDays);
      const expiryCn = fmtExpiryCn(it.expiry);
      let uid = ('linqi-' + String(it.id).replace(/[^A-Za-z0-9]/g, '')).slice(0, 60);
      while (uids[uid]) uid = uid + '-x';
      uids[uid] = 1;
      lines.push('BEGIN:VEVENT');
      lines.push('UID:' + uid + '@linqi.local');
      lines.push('DTSTAMP:' + icsStamp());
      lines.push('DTSTART;VALUE=DATE:' + it.expiry.replace(/-/g, ''));
      lines.push('DTEND;VALUE=DATE:' + compactDate(addDays(parseDate(it.expiry), 1)));
      lines.push('SUMMARY:【到期提醒】' + it.name + ' ' + alertRemain + '（' + expiryCn + '）');
      lines.push('DESCRIPTION:' + suggestion(remindDays));
      lines.push('BEGIN:VALARM');
      lines.push('TRIGGER:-PT' + ((remindDays - 1) * 24 + 15) + 'H');
      lines.push('ACTION:DISPLAY');
      lines.push('DESCRIPTION:' + it.name + ' ' + alertRemain + '（' + expiryCn + '）');
      lines.push('END:VALARM');
      lines.push('END:VEVENT');
    });
    lines.push('END:VCALENDAR');
    const content = lines.join('\r\n') + '\r\n';
    const blob = new Blob([content], { type: 'text/calendar;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `linqi-qingdan-${compactDate(new Date())}.ics`;
    document.body.appendChild(a);
    a.click();
    setTimeout(() => {
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }, 200);
    showToast(`已生成日历文件，共 ${active.length} 个到期提醒`);
    setShowTutorial(true);
  };

  const exportJson = () => {
    const real = visibleItems.filter(it => !String(it.id).startsWith('sample-'));
    if (real.length === 0) {
      showToast('还没有可备份的数据', 'error');
      return;
    }
    const blob = new Blob([JSON.stringify(real, null, 2)], { type: 'application/json;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `linqi-qingdan-backup-${compactDate(new Date())}.json`;
    document.body.appendChild(a);
    a.click();
    setTimeout(() => {
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }, 200);
    showToast('已导出备份文件');
  };

  const handleImportFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async () => {
      const text = String(reader.result || '');
      let parsed: ExpiryItem[] | null = null;
      try { parsed = JSON.parse(text); } catch { parsed = null; }
      if (!parsed || !Array.isArray(parsed)) {
        showToast('文件格式不正确，请检查', 'error');
        return;
      }
      setConfirmData({
        title: '恢复数据',
        msg: `将用备份文件中的 ${parsed.length} 条记录覆盖当前清单，当前数据会被替换。确定恢复吗？`,
        confirmText: '恢复',
        danger: true,
        onConfirm: async () => {
          try {
            await clearAllItems();
            const imported = await batchImport({ items: parsed as any });
            setItems(imported);
            setSamplesVisible(false);
            showToast(`已恢复 ${imported.length} 条记录`);
          } catch (err) {
            logger.error('恢复失败', err);
            showToast('恢复失败，请重试', 'error');
          }
        },
      });
      setShowConfirm(true);
    };
    reader.onerror = () => { showToast('文件读取失败，请重试', 'error'); };
    reader.readAsText(file, 'utf-8');
  };

  const renderCalendarDays = () => {
    const now = new Date();
    const y = calView.y || now.getFullYear();
    const m = calView.m !== undefined ? calView.m : now.getMonth();
    const first = new Date(y, m, 1);
    const startWeekday = first.getDay();
    const daysInMonth = new Date(y, m + 1, 0).getDate();
    const cells: React.ReactNode[] = [];
    for (let i = 0; i < startWeekday; i++) {
      cells.push(<span key={`blank-${i}`} className="dp-day blank" />);
    }
    for (let d = 1; d <= daysInMonth; d++) {
      const ds = `${y}-${String(m + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
      const isToday = ds === todayStr();
      const isSel = ds === dateInput;
      cells.push(
        <button
          key={ds}
          type="button"
          className={`dp-day${isSel ? ' sel' : ''}${isToday ? ' today' : ''}`}
          onClick={() => {
            setDateInput(ds);
            setShowCalendar(false);
            nameInputRef.current?.focus();
          }}
        >
          {d}
        </button>,
      );
    }
    return cells;
  };

  const openCalendar = () => {
    const now = new Date();
    let y = now.getFullYear();
    let m = now.getMonth();
    if (dateInput) {
      const d = parseDate(dateInput);
      y = d.getFullYear();
      m = d.getMonth();
    }
    setCalView({ y, m });
    setShowCalendar(true);
  };

  const calPrev = () => {
    setCalView(prev => {
      let m = prev.m - 1;
      let y = prev.y;
      if (m < 0) { m = 11; y--; }
      return { y, m };
    });
  };

  const calNext = () => {
    setCalView(prev => {
      let m = prev.m + 1;
      let y = prev.y;
      if (m > 11) { m = 0; y++; }
      return { y, m };
    });
  };

  const calToday = () => {
    setDateInput(todayStr());
    setShowCalendar(false);
    nameInputRef.current?.focus();
  };

  const monthPillCount = (() => {
    const now = new Date();
    const ym = now.getFullYear() + '-' + String(now.getMonth() + 1).padStart(2, '0');
    return visibleItems.filter(it =>
      it.displayStatus === 'thrown' &&
      String(it.markerProcessedAt).indexOf(ym) === 0
    ).length;
  })();

  const activeCountLabel = visibleItems.length > 0 ? `共 ${visibleItems.length} 条` : '';

  const hasRealData = visibleItems.length > 0;
  const allProcessed = hasRealData && activeItems.length === 0;

  const showEmpty = searchedActive.length === 0 && searchQuery.trim() === '';
  const showNoResult = searchedActive.length === 0 && searchQuery.trim() !== '';

  return (
    <div className="expiry-app">
      <div className="expiry-page">
        <header className="topbar">
          <div className="brand">
            <span className="brand-icon">
              <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="#fff" strokeWidth="1.8" strokeLinecap="round">
                <rect x="5" y="2.5" width="14" height="19" rx="2.5" />
                <path d="M5 9.5h14" />
                <path d="M9 5.5v1" />
                <path d="M9 14v2" />
              </svg>
            </span>
            <span className="brand-text">
              <h1>临期清单</h1>
              <span className="sub">会过期的东西，到点提醒你</span>
            </span>
          </div>
          <div className="top-actions">
            <button className="btn btn-primary" type="button" onClick={exportIcs}>
              <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M12 3v12" />
                <path d="M7 10l5 5 5-5" />
                <path d="M4 21h16" />
              </svg>
              导出日历
            </button>
            <button className="btn btn-ghost" type="button" onClick={() => setShowTutorial(true)}>
              <span>?</span><span className="tut-txt">怎么导入日历</span>
            </button>
          </div>
        </header>

        <section className="card input-card">
          <div className="input-row">
            <input
              ref={nameInputRef}
              id="name-input"
              type="text"
              placeholder="物品名称"
              maxLength={30}
              value={nameInput}
              onChange={e => { setNameInput(e.target.value); setInputError(false); setInputShake(false); }}
              onKeyDown={e => { if (e.key === 'Enter') { e.preventDefault(); handleAddItem(); } }}
              className={`${inputError ? 'error' : ''} ${inputShake ? 'shake' : ''}`}
              aria-label="物品名称"
            />
            <button
              ref={dateTriggerRef}
              className={`date-trigger${dateInput ? ' has-date' : ''}`}
              type="button"
              aria-haspopup="dialog"
              aria-expanded={showCalendar}
              onClick={e => {
                e.stopPropagation();
                if (showCalendar) setShowCalendar(false);
                else openCalendar();
              }}
            >
              <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
                <rect x="3" y="5" width="18" height="16" rx="2" />
                <path d="M8 3v4" />
                <path d="M16 3v4" />
                <path d="M3 10h18" />
              </svg>
              <span ref={dtTextRef} className="dt-text">
                <span ref={dtScrollRef} className="dt-scroll">
                  {dateInput ? fmtDate(dateInput) : '选择到期时间'}
                </span>
              </span>
            </button>
            <input type="hidden" value={dateInput} aria-label="到期日" />
            {showCalendar && (
              <div ref={datePickerRef} className="date-picker" role="dialog" aria-label="选择到期日">
                <div className="dp-head">
                  <button className="dp-nav" type="button" aria-label="上个月" onClick={calPrev}>◀</button>
                  <span className="dp-title">
                    {calView.y || new Date().getFullYear()}年{(calView.m !== undefined ? calView.m : new Date().getMonth()) + 1}月
                  </span>
                  <button className="dp-nav" type="button" aria-label="下个月" onClick={calNext}>▶</button>
                </div>
                <div className="dp-week"><span>日</span><span>一</span><span>二</span><span>三</span><span>四</span><span>五</span><span>六</span></div>
                <div className="dp-grid">{renderCalendarDays()}</div>
                <div className="dp-foot">
                  <button className="dp-today" type="button" onClick={calToday}>今天</button>
                </div>
              </div>
            )}
            <button id="btn-add" className="btn btn-primary" type="button" onClick={handleAddItem}>记下</button>
          </div>
          <div className="quick-row">
            <span className="quick-label">快捷：</span>
            {[3, 7, 14, 30].map(days => (
              <button
                key={days}
                className={`qbtn${formatDate(addDays(new Date(), days)) === dateInput ? ' active' : ''}`}
                type="button"
                onClick={() => handleQuickDate(days)}
              >
                +{days}天
              </button>
            ))}
          </div>
          <div className="emoji-row">
            <span className="e-label">标签：</span>
            {EMOJI_PICK.map(em => (
              <button
                key={em}
                className={`ebtn${selectedEmoji === em ? ' sel' : ''}`}
                type="button"
                onClick={() => handlePickEmoji(em)}
              >
                {em}
              </button>
            ))}
            <button id="emoji-clear" className="ebtn" type="button" onClick={handleClearEmoji} title="不选标签（显示通用图标）">
              <i className="clear-x">×</i>
            </button>
          </div>
        </section>

        <div className="stats-sticky">
          <div className="card stats-bar">
            <div className="stat" data-k="expired">
              <span className="num">{expiredCount}</span><span className="label">已过期</span>
            </div>
            <div className="stat" data-k="imminent">
              <span className="num">{imminentCount}</span><span className="label">3天内</span>
            </div>
            <div className="stat" data-k="safe">
              <span className="num">{safeCount}</span><span className="label">安全</span>
            </div>
          </div>
        </div>

        {samplesVisible && (
          <div className="sample-bar">
            <span className="s-txt">这是示例数据</span>
            <span className="sbtns">
              <button className="s-clear" type="button" onClick={handleClearSamples}>清空示例，开始记录</button>
              <button className="s-adopt" type="button" onClick={handleAdoptSamples}>用这些示例开始</button>
            </span>
          </div>
        )}

        <section className="card list-card">
          <div className="list-head">
            <span className="list-title">清单</span>
            <span className="list-count">{activeCountLabel}</span>
            {monthPillCount > 0 && (
              <span className="month-pill">本月扔掉 {monthPillCount} 件</span>
            )}
            <div className="search-wrap">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round">
                <circle cx="11" cy="11" r="7" />
                <path d="M20 20l-3.5-3.5" />
              </svg>
              <input
                id="search-input"
                type="text"
                placeholder="搜索"
                autoComplete="off"
                aria-label="搜索"
                value={searchQuery}
                onChange={e => { setSearchQuery(e.target.value); setCurrentPage(1); }}
              />
            </div>
          </div>
          <ul id="item-list">
            {pageList.map(it => {
              const days = daysUntil(it.expiry);
              const st = statusOf(days);
              return (
                <li key={it.id} className={`row ${st}`} data-id={it.id}>
                  <span className="dot" />
                  <span className="emoji">{it.emoji ? it.emoji : <GenericIcon />}</span>
                  <div className="row-main">
                    <span className="name">{it.name}</span>
                    <div className="meta">
                      <span>{fmtDate(it.expiry)}</span>
                      <span className="days">{statusText(days)}</span>
                    </div>
                  </div>
                  <div className="row-actions">
                    <button className="act eat" title="已吃掉" onClick={() => handleMarkStatus(it.id, 'eaten')}>
                      <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M5 13l4 4L19 7" />
                      </svg>
                    </button>
                    <button className="act throw" title="已扔掉" onClick={() => handleMarkStatus(it.id, 'thrown')}>
                      <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M6 6l12 12" />
                        <path d="M18 6L6 18" />
                      </svg>
                    </button>
                    <button className="act del" title="删除" onClick={() => handleRemoveItem(it.id)}>
                      <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M4 7h16" />
                        <path d="M9 7V5a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2" />
                        <path d="M6 7l1 13a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1l1-13" />
                        <path d="M10 11v6M14 11v6" />
                      </svg>
                    </button>
                  </div>
                </li>
              );
            })}
          </ul>
          {totalPages > 1 && (
            <div className="pager">
              <button
                className="pg-btn"
                type="button"
                disabled={safePage <= 1}
                onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
              >
                ‹ 上一页
              </button>
              <span className="pg-info">第 {safePage} / {totalPages} 页</span>
              <button
                className="pg-btn"
                type="button"
                disabled={safePage >= totalPages}
                onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
              >
                下一页 ›
              </button>
            </div>
          )}
          {showEmpty && (
            <div className="empty">
              <span className="e-emoji">{allProcessed ? '🧹' : '🥛'}</span>
              <p className="e-title">{allProcessed ? '都处理完啦' : '还没有记录任何东西'}</p>
              <p className="e-sub">{allProcessed ? '清单空了，再记一件新的吧' : '从冰箱里拿一件出来试试 —— 比如牛奶，还剩几天？'}</p>
            </div>
          )}
          {showNoResult && (
            <div className="empty">
              <span className="e-emoji">🔍</span>
              <p className="e-title">没有找到相关条目</p>
            </div>
          )}
          <div id="print-list">
            {searchedActive.map(it => {
              const days = daysUntil(it.expiry);
              const st = statusOf(days);
              return (
                <div key={it.id} className={`row ${st}`}>
                  <span className="dot" />
                  <span className="emoji">{it.emoji ? it.emoji : <GenericIcon />}</span>
                  <div className="row-main">
                    <span className="name">{it.name}</span>
                    <div className="meta">
                      <span>{fmtDate(it.expiry)}</span>
                      <span className="days">{statusText(days)}</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </section>

        {processedItems.length > 0 && (
          <section className="processed">
            <button
              className={`p-toggle${processedOpen ? ' open' : ''}`}
              type="button"
              onClick={() => setProcessedOpen(!processedOpen)}
            >
              <span>已处理</span>
              <span className="p-cnt">({processedItems.length})</span>
              <svg className="arrow" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M6 9l6 6 6-6" />
              </svg>
            </button>
            {processedOpen && (
              <ul className="p-list">
                {processedItems.map(it => (
                  <li key={it.id} className="p-row">
                    <span className="emoji">{it.emoji ? it.emoji : <GenericIconSm />}</span>
                    <span className="p-name">{it.name}</span>
                    <span className={`p-badge${it.displayStatus === 'thrown' ? ' thrown' : ''}`}>
                      {it.displayStatus === 'eaten' ? '已吃掉' : '已扔掉'}
                    </span>
                    <span className="p-date">{fmtDate(it.markerProcessedAt || it.expiry)}</span>
                    <div className="p-actions">
                      <button className="pact" title="恢复" onClick={() => handleRestoreItem(it.id)}>
                        <svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <path d="M3 7v6h6" />
                          <path d="M3 13a9 9 0 1 0 2.5-6.3L3 7" />
                        </svg>
                      </button>
                      <button className="pact del" title="删除" onClick={() => handleRemoveItem(it.id)}>
                        <svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <path d="M4 7h16" />
                          <path d="M9 7V5a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2" />
                          <path d="M6 7l1 13a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1l1-13" />
                          <path d="M10 11v6M14 11v6" />
                        </svg>
                      </button>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </section>
        )}

        <div className="card bottom-bar">
          <button className="bbtn" type="button" onClick={exportIcs}>
            <svg className="bi" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M12 3v12" />
              <path d="M7 10l5 5 5-5" />
              <path d="M4 21h16" />
            </svg>
            导出日历
          </button>
          <button className="bbtn" type="button" onClick={() => window.print()}>
            <svg className="bi" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M7 8V3h10v5" />
              <rect x="4" y="8" width="16" height="9" rx="2" />
              <path d="M7 14h10v7H7z" />
            </svg>
            打印清单
          </button>
          <button className="bbtn" type="button" onClick={exportJson}>
            <svg className="bi" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M12 3a5 5 0 0 0-4.6 7A4 4 0 0 0 5 18h14a4 4 0 0 0-1.4-7.8A5 5 0 0 0 12 3z" />
              <path d="M12 11v6" />
              <path d="M9 14l3 3 3-3" />
            </svg>
            备份 JSON
          </button>
          <button className="bbtn" type="button" onClick={() => fileInputRef.current?.click()}>
            <svg className="bi" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M12 17V6" />
              <path d="M8 10l4-4 4 4" />
              <path d="M4 21h16" />
            </svg>
            恢复数据
          </button>
        </div>

        <p className="foot-note">
          数据保存在云端，电脑手机同步 · 到期提醒：提前
          <select value={remindDays} aria-label="提醒提前天数" onChange={handleRemindChange}>
            <option value="0">0 天（当天）</option>
            <option value="1">1 天</option>
            <option value="2">2 天</option>
            <option value="3">3 天</option>
            <option value="7">7 天</option>
          </select>
          提醒
        </p>
      </div>

      <div className="print-head">
        <h1>临期清单</h1>
        <p>打印于 {fmtDate(todayStr())} · 待处理 {activeItems.filter(it => !String(it.id).startsWith('sample-')).length} 件</p>
      </div>

      <input ref={fileInputRef} type="file" accept=".json,application/json" style={{ display: 'none' }} onChange={handleImportFile} />

      <div className="toast-container">
        {toasts.map(t => (
          <div key={t.id} className={`toast${t.type === 'error' ? ' toast-error' : ''} show`}>
            {t.msg}
          </div>
        ))}
      </div>

      {showConfirm && confirmData && (
        <div className="modal-mask" onClick={e => { if (e.target === e.currentTarget) { setShowConfirm(false); setConfirmData(null); } }}>
          <div className="modal confirm" role="dialog" aria-modal="true">
            <div className="m-title">{confirmData.title}</div>
            <div className="m-msg">{confirmData.msg}</div>
            <div className="m-actions">
              <button className="btn btn-ghost" type="button" onClick={() => { setShowConfirm(false); setConfirmData(null); }}>取消</button>
              <button
                className={`btn ${confirmData.danger ? 'btn-danger' : 'btn-primary'}`}
                type="button"
                onClick={() => {
                  const cb = confirmData.onConfirm;
                  setShowConfirm(false);
                  setConfirmData(null);
                  cb();
                }}
              >
                {confirmData.confirmText}
              </button>
            </div>
          </div>
        </div>
      )}

      {showTutorial && (
        <div className="modal-mask" onClick={e => { if (e.target === e.currentTarget) setShowTutorial(false); }}>
          <div className="modal tut" role="dialog" aria-modal="true">
            <div className="m-head">
              <h2>怎么导入日历</h2>
              <button className="close" type="button" aria-label="关闭" onClick={() => setShowTutorial(false)}>✕</button>
            </div>
            <div className="seg">
              <button
                className={tutPlatform === 'ios' ? 'on' : ''}
                type="button"
                onClick={() => setTutPlatform('ios')}
              >
                iPhone / iPad
              </button>
              <button
                className={tutPlatform === 'android' ? 'on' : ''}
                type="button"
                onClick={() => setTutPlatform('android')}
              >
                安卓
              </button>
            </div>
            <ol className="steps">
              {(tutPlatform === 'ios' ? TUT_IOS : TUT_ANDROID).map((t, i) => (
                <li key={i}>
                  <span className="n">{i + 1}</span>
                  <span className="t">{t}</span>
                </li>
              ))}
            </ol>
            <p className="compliance">
              本功能通过导出标准 .ics 日历文件实现，由你手机自带的日历 App 完成提醒，非苹果官方接口接入。
            </p>
            <p className="tip">
              如果导入后没收到提醒：请检查系统「设置 → 通知 → 日历」是否允许通知，并确认未开启专注模式/免打扰。
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
