import { Inject, Injectable, Logger, OnModuleInit } from '@nestjs/common';
import { DRIZZLE_DATABASE } from '@lark-apaas/fullstack-nestjs-core';
import { sql } from 'drizzle-orm';

/**
 * 部署基础设施（非业务代码）：应用启动时幂等建表 + 授权 + 匿名访问策略。
 * 妙搭全栈平台不会自动为 drizzle 表建表（或仅在特定发布时机同步）；
 * 且命令行/管理 API（sql_commands）只作用于控制台库，运行时连接的是独立线上库。
 * 因此本钩子在运行时自己的数据库连接上执行：建表、授权、RLS 匿名策略，
 * 保证线上库表结构就位、匿名访客可完整使用（添加/软标记/软删除）。
 * 建表 SQL 与 server/database/schema.ts 保持一致；user_profile 类型按连接串
 * schema 限定，DEFAULT 用显式 `NULL::user_profile`（平台 42804 修复）。
 */
@Injectable()
export class SchemaInitService implements OnModuleInit {
  private readonly logger = new Logger('SchemaInit');

  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: any,
  ) {}

  async onModuleInit(): Promise<void> {
    try {
      const url = process.env.SUDA_DATABASE_URL || '';
      let schema = 'public';
      try {
        const sp = new URL(url).searchParams.get('schema');
        if (sp) schema = sp;
      } catch {
        /* 保留默认 */
      }
      const profileType = `${schema}.user_profile`;

      const ddl = `
CREATE TABLE IF NOT EXISTS expiry_setting (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  setting_key varchar(64) NOT NULL,
  setting_value varchar(255) NOT NULL,
  _created_at timestamptz(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  _created_by ${profileType} DEFAULT (CASE WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL::${profileType} END),
  _updated_at timestamptz(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  _updated_by ${profileType} DEFAULT (CASE WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL::${profileType} END),
  CONSTRAINT expiry_setting_pkey PRIMARY KEY (id)
);
CREATE UNIQUE INDEX IF NOT EXISTS expiry_setting_setting_key_key ON expiry_setting (setting_key);
CREATE TABLE IF NOT EXISTS expiry_item (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  name varchar(255) NOT NULL,
  emoji varchar(32) NOT NULL,
  expiry date NOT NULL,
  status varchar(32) NOT NULL DEFAULT 'active',
  processed_at date,
  created_at date NOT NULL DEFAULT CURRENT_DATE,
  _created_by ${profileType} DEFAULT (CASE WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL::${profileType} END),
  _updated_at timestamptz(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  _updated_by ${profileType} DEFAULT (CASE WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL::${profileType} END),
  CONSTRAINT expiry_item_pkey PRIMARY KEY (id)
);
CREATE INDEX IF NOT EXISTS idx_expiry_item_status ON expiry_item (status);
CREATE INDEX IF NOT EXISTS idx_expiry_item_expiry ON expiry_item (expiry);
`;
      await this.db.execute(sql.raw(ddl));
      this.logger.log(`DDL ok (schema=${schema})`);

      const grants = `
GRANT USAGE ON SCHEMA public TO anon, authenticated, service_role, anon_${schema}, authenticated_${schema}, service_role_${schema};
GRANT SELECT, INSERT, UPDATE, DELETE ON expiry_item, expiry_setting TO anon, authenticated, service_role, anon_${schema}, authenticated_${schema}, service_role_${schema};
GRANT USAGE ON TYPE ${profileType} TO anon, authenticated, service_role, anon_${schema}, authenticated_${schema}, service_role_${schema};
`;
      try {
        await this.db.execute(sql.raw(grants));
        this.logger.log('Grants ok');
      } catch (e) {
        this.logger.warn(`Grants skipped: ${(e as Error).message}`);
      }

      // 匿名访客全操作策略：本应用为「互联网公开 · 无需登录」，
      // 匿名软标记/软删除依赖匿名 INSERT/UPDATE/DELETE。RLS 保持启用，
      // 仅为 anon/authenticated 角色补全 ALL 策略（幂等）。
      const policies = `
DO $$
DECLARE
  r text;
  rl text := '';
BEGIN
  FOR r IN SELECT rolname FROM pg_roles WHERE rolname IN ('anon', 'anon_${schema}', 'authenticated', 'authenticated_${schema}') LOOP
    rl := rl || CASE WHEN rl = '' THEN '' ELSE ', ' END || quote_ident(r);
  END LOOP;
  IF rl <> '' THEN
    EXECUTE 'DROP POLICY IF EXISTS anon_all_policy ON expiry_item';
    EXECUTE 'CREATE POLICY anon_all_policy ON expiry_item FOR ALL TO ' || rl || ' USING (true) WITH CHECK (true)';
    EXECUTE 'DROP POLICY IF EXISTS anon_all_policy ON expiry_setting';
    EXECUTE 'CREATE POLICY anon_all_policy ON expiry_setting FOR ALL TO ' || rl || ' USING (true) WITH CHECK (true)';
  END IF;
END $$;
`;
      try {
        await this.db.execute(sql.raw(policies));
        this.logger.log('Anon policies ok');
      } catch (e) {
        this.logger.warn(`Anon policies skipped: ${(e as Error).message}`);
      }
    } catch (e) {
      this.logger.error(`SchemaInit failed: ${(e as Error).message}`);
    }
  }
}
